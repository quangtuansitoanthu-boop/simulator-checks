import { describe, expect, it } from 'vitest';
import { contentExperienceNotice, hasContentExperienceNotice } from '../../src/lib/i18n/content-experience-notice';

describe('Facebook Quang Từ collection notice', () => {
  it.each([
    ['vi', 'Các thông tin trong tuyển tập này được tổng hợp từ các kênh công khai, hiểu biết của tác giả và Internet, đều là những trải nghiệm cá nhân, không khẳng định tất cả đều có thật, do đó quý vị tin thì suy ngẫm không tin xem giải trí ạ'],
    ['en', 'The information in this collection is compiled from public channels, the author’s knowledge and the Internet. These are personal experiences, and we do not assert that everything is true. If you believe them, please reflect on them; if not, please enjoy them as entertainment.'],
  ] as const)('shows the collection wording with the existing banner in %s', (locale, message) => {
    const id = 'tuyen-tap-phap-facebook-quang-tu';
    expect(hasContentExperienceNotice(id)).toBe(true);
    const notice = contentExperienceNotice(id, locale);
    expect(notice && { title: notice.title, timeout: notice.timeout, message: notice.message }).toEqual({
      title: locale === 'vi' ? 'Lưu ý về nội dung' : 'About these stories',
      timeout: locale === 'vi' ? 'Tự ẩn sau 10 giây' : 'Disappears after 10 seconds',
      message,
    });
  });
});

describe('Thiên Đường Du Kí notice', () => {
  it.each(['vi', 'en'] as const)('shares the approved Địa Ngục Du Ký notice in %s', locale => {
    expect(hasContentExperienceNotice('thien-duong-du-ki')).toBe(true);
    expect(contentExperienceNotice('thien-duong-du-ki', locale)).toEqual(
      contentExperienceNotice('tt_1781452671270', locale)
    );
    expect(contentExperienceNotice('thien-duong-du-ki', locale)?.timeout).toBe(
      locale === 'vi' ? 'Tự ẩn sau 10 giây' : 'Disappears after 10 seconds'
    );
  });

  it('keeps existing story notices and ignores unrelated content', () => {
    for (const id of ['tt_1781452671270', 'tt_1781517395283', 'tt_1781081372340_1_xqcxo',
      'pt_1781961851755', 'phat-tu-thien-dia-du-ky-quyen-1']) {
      expect(hasContentExperienceNotice(id)).toBe(true);
      expect(contentExperienceNotice(id, 'vi')?.message).toBeTruthy();
    }
    expect(hasContentExperienceNotice('unrelated-book')).toBe(false);
    expect(contentExperienceNotice('unrelated-book', 'vi')).toBeNull();
  });
});
