import { describe, expect, it } from 'vitest';
import { contentExperienceNotice, hasContentExperienceNotice } from '../../src/lib/i18n/content-experience-notice';

describe('Thiên Đường Du Kí notice', () => {
  it.each(['vi', 'en'] as const)('shares the approved Địa Ngục Du Ký notice in %s', locale => {
    expect(hasContentExperienceNotice('thien-duong-du-ki')).toBe(true);
    expect(contentExperienceNotice('thien-duong-du-ki', locale)).toEqual(
      contentExperienceNotice('tt_1781452671270', locale)
    );
    expect(contentExperienceNotice('thien-duong-du-ki', locale)?.timeout).toBe(
      locale === 'vi' ? 'Tự ẩn sau 10 giây' : 'Disappears after 10 seconds'
    );
  });

  it('keeps existing story notices and ignores unrelated content', () => {
    for (const id of ['tt_1781452671270', 'tt_1781517395283', 'tt_1781081372340_1_xqcxo',
      'pt_1781961851755', 'phat-tu-thien-dia-du-ky-quyen-1']) {
      expect(hasContentExperienceNotice(id)).toBe(true);
      expect(contentExperienceNotice(id, 'vi')?.message).toBeTruthy();
    }
    expect(hasContentExperienceNotice('unrelated-book')).toBe(false);
    expect(contentExperienceNotice('unrelated-book', 'vi')).toBeNull();
  });
});
