<script lang="ts">
  import { Bird } from '@lucide/svelte';
  import { modalDialog } from '$lib/browser/modal-dialog';
  import { getLocaleContext } from '$lib/stores/locale.svelte';
  import { refugeReleaseBlocks, refugeReleaseCopy } from '$lib/i18n/refuge-release';
  import '$lib/styles/home-action-banner.css';

  const localeStore = getLocaleContext();
  const copy = $derived(refugeReleaseCopy[localeStore.current === 'en' ? 'en' : 'vi']);
  let open = $state(false);
</script>

<button
  class="pbb-compact refuge-release-banner"
  type="button"
  aria-haspopup="dialog"
  aria-expanded={open}
  onclick={() => open = true}
>
  <span class="pbb-compact-icon" aria-hidden="true"><Bird size={22} /></span>
  <span class="pbb-compact-title">{copy.title}</span>
  <span class="pbb-compact-arrow" aria-hidden="true">→</span>
</button>

{#if open}
  <dialog class="refuge-release-dialog" use:modalDialog aria-labelledby="refuge-release-title" oncancel={() => open = false} onclose={() => open = false}>
    <div class="ritual-shell">
      <header class="ritual-header">
        <h1 id="refuge-release-title" tabindex="-1" data-modal-focus>{copy.heading}</h1>
        <button type="button" aria-label={copy.close} onclick={() => open = false}>×</button>
      </header>
      <article class="ritual-content" lang="vi">
        {#each refugeReleaseBlocks as block, index (index)}
          <svelte:element
            this={block.kind === 'heading' ? 'h2' : block.kind === 'step' ? 'h3' : 'p'}
            class="ritual-block"
            class:ritual-heading={block.kind === 'heading' || block.kind === 'step'}
            class:ritual-verse={block.kind === 'verse'}
          >
            {#each block.text.split(/(\([^)]*\))/u) as part, partIndex (partIndex)}
              {#if part.startsWith('(') && part.endsWith(')')}<em>{part}</em>{:else}{part}{/if}
            {/each}
          </svelte:element>
        {/each}
      </article>
    </div>
  </dialog>
{/if}

<style>
  .refuge-release-banner {
    margin-block-start: calc(var(--notice-padding) - var(--home-section-gap));
    background: linear-gradient(110deg, color-mix(in srgb, var(--practice-card-blue-start) 80%, var(--practice-card-blue-ink)), color-mix(in srgb, var(--practice-card-blue-end) 80%, var(--practice-card-blue-ink)));
    color: color-mix(in srgb, var(--practice-card-blue-ink) 50%, var(--on-gold));
    border-color: var(--practice-card-blue-start);
    box-shadow: var(--shadow);
  }
  .refuge-release-banner:hover { box-shadow: var(--shadow); }
  .refuge-release-banner .pbb-compact-title { white-space: normal; overflow: visible; }
  .refuge-release-banner .pbb-compact-arrow { color: inherit; }
  .refuge-release-dialog {
    margin: auto;
    padding: 0;
    border: 1px solid var(--border);
    border-radius: var(--radius-card);
    background: var(--card);
    color: var(--text);
    width: min(var(--practice-dialog-width), calc(100% - var(--space-page) * 2));
    height: var(--practice-dialog-height);
    max-height: calc(100dvh - var(--space-page) * 2);
    overflow: hidden;
    box-shadow: var(--shadow-xl);
  }
  .refuge-release-dialog::backdrop { background: var(--practice-dialog-backdrop); }
  .ritual-shell { display: flex; flex-direction: column; height: 100%; min-height: 0; }
  .ritual-header { display: flex; align-items: center; gap: var(--notice-gap); padding: var(--notice-padding) var(--space-page); border-bottom: 1px solid var(--border); flex: none; }
  .ritual-header h1 { flex: 1; font-size: var(--font-size-card-title); text-align: center; line-height: 1.5; }
  .ritual-header button { width: var(--touch-target-size); height: var(--touch-target-size); flex: none; border: 1px solid var(--border); border-radius: var(--radius-control); background: var(--bg2); color: var(--text); font-size: var(--font-size-section-title); cursor: pointer; }
  .ritual-header button:focus-visible { outline: 2px solid var(--gold); outline-offset: 2px; }
  .ritual-content { padding: var(--space-page); padding-bottom: calc(var(--space-page) + env(safe-area-inset-bottom)); overflow-y: auto; min-height: 0; font-family: var(--font-reader); font-size: var(--font-size-ritual-reading); font-weight: 400; line-height: 1.9; overflow-wrap: anywhere; overscroll-behavior: contain; }
  .ritual-block { text-align: justify; margin: 0 0 var(--space-page); }
  .ritual-heading { text-align: center; font-weight: 700; font-size: var(--font-size-section-title); margin: var(--space-page) 0; }
  .ritual-heading:first-child { margin-top: 0; }
  .ritual-verse { text-align: center; white-space: pre-line; }
  em { font-style: italic; }
  @media (max-width: 600px) {
    .refuge-release-dialog { inset: 0; margin: 0; width: 100%; height: 100dvh; max-height: 100dvh; max-width: none; border-radius: 0; }
    .ritual-header { padding-top: calc(var(--notice-padding) + var(--app-safe-top)); }
  }
</style>
