<script lang="ts">
  import { browser } from '$app/environment';
  import { onMount, tick } from 'svelte';
  import { page as routePage } from '$app/state';
  import { afterNavigate, replaceState } from '$app/navigation';
  import { createQuery, useQueryClient } from '@tanstack/svelte-query';
  import { getSessionContext, GUEST_SESSION, SESSION_CHANGE_EVENT } from '$lib/stores/session.svelte';
  import { getLocaleContext } from '$lib/stores/locale.svelte';
  import { serverStateKeys } from '$lib/browser/server-state';
  import { approveAllMindful, decideModeration, fetchModerationQueue, ModerationApiError, prepareMindfulApproveAll, suspendModerationMember } from '$lib/browser/admin-community-moderation';
  import { createBrowserId } from '$lib/browser/random-id';
  import { adminModerationUi } from '$lib/i18n/admin-community-moderation';
  import { personalPracticeCopy } from '$lib/i18n/personal-practice-copy';
  import type { MindfulApproveAllPreparation, MindfulApproveAllPreparationInput, MindfulModerationKind, MindfulModerationState, ModerationCountSummary, ModerationDecision, ModerationMember, ModerationQueueItem, ModerationQueueKind } from '$lib/contracts/community-moderation';
  import type { PageSessionDTO } from '$lib/server/auth/types';
  import type { AdminMember } from '../members/admin-member-types';
  import AdminMemberSuspendDialog from '../members/AdminMemberSuspendDialog.svelte';
  import AdminModerationDecisionDialog from './AdminModerationDecisionDialog.svelte';
  import '$lib/styles/admin-member-management.css';

  const queryClient = useQueryClient();
  const locale = getLocaleContext();
  const t = $derived(adminModerationUi[locale.current]);
  const keys = serverStateKeys.communityModeration;
  // Context đã có phiên SSR trước khi root đăng ký snapshot cho các browser owner.
  const sessionStore = getSessionContext();
  let session = $state(sessionStore.value);
  const principal = $derived(session.authenticated && session.user?.role === 'admin' ? session.user.id : null);
  let kind = $state<ModerationQueueKind>(routePage.url.searchParams.get('moderation') === 'mindful' ? 'mindful' : 'comments');
  let reviewState = $state<MindfulModerationState>('pending');
  let postKind = $state<MindfulModerationKind | 'all'>('all');
  let cursors = $state<Array<string | null>>([null]);
  let page = $state(0);
  let selected = $state<ModerationQueueItem | null>(null);
  let action = $state<ModerationDecision['action'] | 'approveAll' | null>(null);
  let reason = $state('');
  let busy = $state(false);
  let error = $state('');
  let notice = $state('');
  let conflict = $state(false);
  let suspending = $state<AdminMember | null>(null);
  interface BulkApproval { preparation: MindfulApproveAllPreparation; postKind?: MindfulModerationKind; after: string | null; updated: number; conflicted: number; started: boolean; }
  let bulk = $state<BulkApproval | null>(null);
  let preparationRequest = $state<MindfulApproveAllPreparationInput | null>(null);
  let preparing = $state(false);
  let operationId = '';
  let detail = $state<HTMLElement | null>(null);
  const locked = $derived(busy || Boolean(bulk?.started));
  const bulkProgress = $derived(bulk?.started ? t.bulkProgress.replace('{updated}', String(bulk.updated)).replace('{conflicted}', String(bulk.conflicted)) : '');
  const bulkScope = $derived(bulk ? t.bulkScope.replace('{kind}', bulk.postKind ? t[bulk.postKind] : t.allKinds).replace('{cutoff}', date(bulk.preparation.cutoff)) : '');
  let epoch = 0;
  let mutation: AbortController | null = null;
  function pageKey(owner: string, requestedKind: ModerationQueueKind, after: string | null, requestedState = reviewState, requestedPostKind = postKind) {
    return requestedKind === 'mindful' ? [...keys.kind(owner, requestedKind), requestedState, requestedPostKind, after] : keys.page(owner, requestedKind, after);
  }
  const queue = createQuery(() => {
    const requestedKind = kind;
    const after = cursors[page];
    const requestedState = reviewState, requestedPostKind = postKind;
    return {
      queryKey: pageKey(principal ?? '', requestedKind, after, requestedState, requestedPostKind),
      queryFn: ({ signal }) => fetchModerationQueue(requestedKind, after, signal, requestedKind === 'mindful' ? { state: requestedState, ...(requestedPostKind === 'all' ? {} : { postKind: requestedPostKind }) } : undefined),
      enabled: browser && Boolean(principal), staleTime: 30_000, retry: false,
      refetchOnWindowFocus: false, refetchOnReconnect: false,
    };
  }, () => queryClient);
  const context = $derived(selected?.kind === 'reports' ? selected.target : selected);

  function clearPrivate(next: PageSessionDTO) {
    const previous = principal;
    epoch++; mutation?.abort(); mutation = null;
    selected = null; action = null; suspending = null; reason = ''; busy = false; error = ''; notice = ''; conflict = false;
    bulk = null; preparationRequest = null; preparing = false; operationId = '';
    cursors = [null]; page = 0; session = next;
    if (previous) {
      void queryClient.cancelQueries({ queryKey: keys.principal(previous) });
      queryClient.removeQueries({ queryKey: keys.principal(previous) });
    }
  }
  $effect(() => {
    if (principal && queue.error instanceof ModerationApiError && [401, 403].includes(queue.error.status)) clearPrivate(GUEST_SESSION);
  });
  afterNavigate(({ to }) => {
    if (to?.url.searchParams.get('moderation') === 'mindful' && kind !== 'mindful') changeQueue('mindful', false);
  });
  onMount(() => {
    const changed = (event: Event) => {
      const next = (event as CustomEvent<PageSessionDTO>).detail;
      if (next?.user?.id !== session.user?.id || next?.user?.role !== session.user?.role || next?.authenticated !== session.authenticated) clearPrivate(next ?? GUEST_SESSION);
    };
    window.addEventListener(SESSION_CHANGE_EVENT, changed);
    return () => { epoch++; mutation?.abort(); window.removeEventListener(SESSION_CHANGE_EVENT, changed); };
  });
  function changeQueue(next: ModerationQueueKind, updateUrl = true) {
    if (locked) return;
    if (updateUrl && browser) {
      const url = new URL(window.location.href);
      if (next === 'mindful') url.searchParams.set('moderation', 'mindful');
      else url.searchParams.delete('moderation');
      if (url.href !== window.location.href) replaceState(url, routePage.state);
    }
    kind = next; cursors = [null]; page = 0; selected = null; notice = ''; error = '';
    preparationRequest = null;
  }
  function changeFilter(nextState: MindfulModerationState, nextKind: MindfulModerationKind | 'all') {
    if (locked) return;
    reviewState = nextState; postKind = nextKind; cursors = [null]; page = 0; selected = null; notice = ''; error = ''; preparationRequest = null;
  }
  function changePage(next: number) {
    if (locked) return;
    if (next > page && queue.data?.nextCursor) cursors = [...cursors.slice(0, page + 1), queue.data.nextCursor];
    page = next; selected = null; notice = ''; error = '';
  }
  function open(next: ModerationDecision['action']) { action = next; operationId = createBrowserId(); reason = ''; error = ''; conflict = false; }
  function close() { if (!busy) { action = null; suspending = null; error = ''; conflict = false; if (bulk && !bulk.started) { bulk = null; preparationRequest = null; } } }
  function date(value: string | null | undefined) { return value ? new Date(value).toLocaleString(locale.current === 'en' ? 'en-GB' : 'vi-VN') : t.unavailable; }
  function countLabel(summary: ModerationCountSummary | undefined) { return summary ? summary.capped ? '99+' : String(summary.count) : '…'; }
  function remaining(value: string | null | undefined) {
    if (!value) return t.unavailable;
    const hours = Math.ceil((new Date(value).getTime() - Date.now()) / 3_600_000);
    return hours > 0 ? t.remainingHours.replace('{hours}', String(hours)) : t.dueNow;
  }
  async function select(item: ModerationQueueItem) {
    selected = item; error = '';
    if (item.kind === 'mindful') { await tick(); detail?.focus({ preventScroll: true }); detail?.scrollIntoView({ block: 'nearest', behavior: 'instant' }); }
  }
  function openSuspend(member: ModerationMember) {
    error = '';
    suspending = { ...member, kind: 'member', accountType: member.role === 'admin' ? 'admin' : 'member', email: null,
      username: null, suspendedAt: null, avatarUrl: null, createdAt: null, updatedAt: null };
  }
  async function reload() {
    if (busy) return;
    if (conflict) { bulk = null; preparationRequest = null; }
    close(); selected = null;
    await queryClient.invalidateQueries({ queryKey: pageKey(principal ?? '', kind, cursors[page]), exact: true });
  }
  async function prepareBulk() {
    if (locked || !principal || kind !== 'mindful' || reviewState !== 'pending') return;
    const ticket = epoch, owner = principal, controller = new AbortController();
    preparationRequest ??= { operationId: createBrowserId(), ...(postKind === 'all' ? {} : { postKind }) };
    const request = preparationRequest;
    mutation = controller; busy = true; preparing = true; error = ''; notice = '';
    try {
      const preparation = await prepareMindfulApproveAll(request, controller.signal);
      if (ticket !== epoch || principal !== owner) return;
      bulk = { preparation, ...(request.postKind ? { postKind: request.postKind } : {}), after: null, updated: 0, conflicted: 0, started: false };
      action = 'approveAll'; conflict = false;
    } catch (cause) {
      if (ticket !== epoch || controller.signal.aborted) return;
      if (cause instanceof ModerationApiError && [401, 403].includes(cause.status)) { clearPrivate(GUEST_SESSION); return; }
      if (cause instanceof ModerationApiError && cause.status === 409) preparationRequest = null;
      error = t.bulkPrepareError;
    } finally { if (ticket === epoch) { busy = false; preparing = false; mutation = null; } }
  }
  async function submitBulk() {
    if (busy || !principal || !bulk) return;
    const ticket = epoch, owner = principal, controller = new AbortController();
    mutation = controller; busy = true; error = ''; conflict = false;
    bulk = { ...bulk, started: true };
    try {
      while (bulk) {
        const step: BulkApproval = bulk;
        const result = await approveAllMindful({ operationId: step.preparation.operationId, cutoff: step.preparation.cutoff, after: step.after, ...(step.postKind ? { postKind: step.postKind } : {}) }, controller.signal);
        if (ticket !== epoch || principal !== owner) return;
        if (result.operationId !== step.preparation.operationId || result.cutoff !== step.preparation.cutoff || (result.nextCursor !== null && result.nextCursor === step.after)) throw new ModerationApiError(502);
        bulk = { ...step, after: result.nextCursor, updated: step.updated + result.updated, conflicted: step.conflicted + result.conflicted };
        if (result.nextCursor === null) {
          notice = `${t.bulkDone} ${t.bulkProgress.replace('{updated}', String(bulk.updated)).replace('{conflicted}', String(bulk.conflicted))}`;
          action = null; bulk = null; preparationRequest = null; selected = null; cursors = [null]; page = 0;
          await queryClient.invalidateQueries({ queryKey: keys.kind(owner, 'mindful') });
          break;
        }
      }
    } catch (cause) {
      if (ticket !== epoch || controller.signal.aborted) return;
      if (cause instanceof ModerationApiError && [401, 403].includes(cause.status)) { clearPrivate(GUEST_SESSION); return; }
      conflict = cause instanceof ModerationApiError && [404, 409].includes(cause.status);
      error = conflict ? t.conflict : t.bulkFailed;
    } finally { if (ticket === epoch) { busy = false; mutation = null; } }
  }
  async function submit(suspend = false) {
    if (action === 'approveAll') { await submitBulk(); return; }
    if (busy || !principal || (!suspend && (!action || !selected))) return;
    if (action === 'reject' && !reason.trim()) { error = t.reasonRequired; return; }
    const target = action === 'hide' ? selected?.target : selected;
    if (!suspend && !target) return;
    const ticket = epoch, owner = principal, controller = new AbortController();
    mutation = controller; busy = true; error = ''; conflict = false;
    try {
      if (suspend && suspending) await suspendModerationMember(suspending.id, controller.signal);
      else if (action && target) await decideModeration(target.kind, target.id, {
        action, revision: target.revision, ...(target.kind === 'mindful' ? { operationId } : {}), ...(action === 'reject' ? { reason: reason.trim() } : {}),
      }, controller.signal);
      if (ticket !== epoch || principal !== owner) return;
      notice = suspend ? t.suspended : t.saved;
      if (action === 'hide' && target) void queryClient.invalidateQueries({ queryKey: keys.kind(owner, target.kind), refetchType: 'none' });
      action = null; suspending = null; selected = null; reason = '';
      await queryClient.invalidateQueries({ queryKey: keys.kind(owner, kind) });
    } catch (cause) {
      if (ticket !== epoch || controller.signal.aborted) return;
      if (cause instanceof ModerationApiError && [401, 403].includes(cause.status)) { clearPrivate(GUEST_SESSION); return; }
      conflict = cause instanceof ModerationApiError && [404, 409].includes(cause.status);
      error = conflict ? t.conflict : t.error;
    } finally {
      if (ticket === epoch) { busy = false; mutation = null; }
    }
  }
</script>

<section class="admin-moderation" class:admin-moderation-mindful={kind === 'mindful'} aria-labelledby="admin-moderation-title" aria-busy={busy || queue.isFetching}>
  <header><h2 id="admin-moderation-title">{kind === 'mindful' ? t.mindfulTitle : t.title}</h2><p>{kind === 'mindful' ? t.mindfulDescription : t.description}</p></header>
  {#if !principal}<p role="alert">{t.forbidden}</p>
  {:else}
    <nav class="admin-moderation-tabs" aria-label={t.title}>
      {#each ['comments', 'profiles', 'reports', 'mindful'] as value (value)}
        <button type="button" aria-pressed={kind === value} disabled={locked} onclick={() => changeQueue(value as ModerationQueueKind)}>{t[value as ModerationQueueKind]}</button>
      {/each}
    </nav>
    {#if kind === 'mindful'}
      <nav class="admin-moderation-tabs mindful-state-tabs" aria-label={t.mindfulState}>
        {#each ['pending', 'published'] as value (value)}
          <button type="button" aria-pressed={reviewState === value} disabled={locked} onclick={() => changeFilter(value as MindfulModerationState, postKind)}>{t[value as MindfulModerationState]} <span>{countLabel(queue.data?.summary?.[value as MindfulModerationState])}</span></button>
        {/each}
      </nav>
      <div class="admin-moderation-actions mindful-filter" role="group" aria-label={t.postKindFilter}>
        {#each ['all', 'repentance', 'good_deed'] as value (value)}
          <button type="button" aria-pressed={postKind === value} disabled={locked} onclick={() => changeFilter(reviewState, value as MindfulModerationKind | 'all')}>{value === 'all' ? t.allKinds : t[value as MindfulModerationKind]}</button>
        {/each}
      </div>
      {#if reviewState === 'pending'}
        <div class="admin-moderation-actions mindful-bulk-actions">
          <button type="button" class="primary" disabled={locked || queue.isFetching || !queue.data?.summary?.pending.count} onclick={() => void prepareBulk()}>{preparing ? t.preparing : t.approveAll}{#if !preparing} ({countLabel(queue.data?.summary?.pending)}){/if}</button>
        </div>
      {/if}
      {#if bulk?.started && action !== 'approveAll'}
        <div class="mindful-bulk-progress"><p role="status">{bulkProgress}</p><p>{t.bulkFailed}</p><button type="button" onclick={() => { action = 'approveAll'; }}>{t.resume}</button></div>
      {/if}
      {#if error && !action}<p class="admin-moderation-error" role="alert">{error}</p>{/if}
    {/if}
    {#if notice}<p role="status">{notice}</p>{/if}
    {#if queue.isPending}<p role="status">{t.loading}</p>
    {:else if queue.isError}<p role="alert">{t.loadError}</p><button type="button" onclick={reload}>{t.retry}</button>
    {:else if !queue.data?.items.length}<p class="admin-moderation-empty">{kind === 'mindful' ? reviewState === 'pending' ? t.emptyPending : t.emptyPublished : t.empty}</p>
    {:else}
      <div class="admin-moderation-grid">
        <div class="admin-moderation-list">
          {#each queue.data.items as item (item.id)}
            <article class="admin-moderation-card" class:mindful-selected={item.kind === 'mindful' && selected?.id === item.id}>
              <small>{item.kind === 'mindful' ? item.mindfulKind ? t[item.mindfulKind] : t.mindful : item.kind === 'reports' ? t.openReport : t.pending}</small>
              {#if item.kind === 'mindful'}<small>{reviewState === 'pending' ? t.pending : t.published}</small>{/if}
              {#if item.kind !== 'mindful' && item.avatarUrl}<img src={item.avatarUrl} alt="" width="34" height="34" referrerpolicy="no-referrer" />{/if}
              <h3>{item.displayName}</h3><time datetime={item.submittedAt}>{new Date(item.submittedAt).toLocaleString(locale.current === 'en' ? 'en-GB' : 'vi-VN')}</time><p>{item.content}</p>
              {#if item.kind === 'mindful' && reviewState === 'pending'}<small>{remaining(item.reviewDueAt)}</small>{/if}
              <button type="button" disabled={locked} aria-pressed={item.kind === 'mindful' ? selected?.id === item.id : undefined} onclick={() => void select(item)}>{item.kind === 'mindful' ? t.viewMindful : t.view}</button>
            </article>
          {/each}
        </div>
        {#if selected}
          <article class="admin-moderation-card admin-moderation-context" aria-label={selected.kind === 'mindful' ? t.mindfulContext : t.context} tabindex="-1" bind:this={detail}>
            <h3>{selected.kind === 'mindful' ? t.mindfulContext : t.context}</h3>
            {#if selected.kind === 'reports'}<p><strong>{t.reportReason}:</strong> {selected.reportReason ? t[selected.reportReason] : ''}</p><p>{selected.content}</p>{/if}
            {#if context}
              <h4>{context.displayName}</h4>
              {#if context.kind !== 'mindful' && context.avatarUrl}<img src={context.avatarUrl} alt={context.displayName} width="64" height="64" referrerpolicy="no-referrer" />{/if}
              {#if context.kind === 'profiles'}<p>{t.submittedIdentity}</p>{/if}
              <p>{context.content}</p>
              {#if selected.kind === 'mindful'}
                <dl class="mindful-review-meta"><div><dt>{t.submitted}</dt><dd>{date(selected.submittedAt)}</dd></div><div><dt>{reviewState === 'pending' ? t.reviewDue : selected.reviewState === 'auto_approved' ? t.autoPublished : t.publishedAt}</dt><dd>{date(reviewState === 'pending' ? selected.reviewDueAt : selected.publishedAt)}</dd></div>{#if reviewState === 'pending'}<div><dt>{t.remaining}</dt><dd>{remaining(selected.reviewDueAt)}</dd></div>{/if}</dl>
              {/if}
              {#if context.articleId}<p><strong>{t.article}:</strong> {context.articleTitle || context.articleId}</p>{/if}
              {#if context.parentId}<blockquote><strong>{t.parent}:</strong> {context.parentContent || t.unavailable}</blockquote>{/if}
              {#if selected.kind === 'profiles' && selected.approvedIdentity}
                <div><strong>{t.approvedIdentity}</strong><p>{selected.approvedIdentity.displayName}</p>
                  {#if selected.approvedIdentity.avatarUrl}<img src={selected.approvedIdentity.avatarUrl} alt={selected.approvedIdentity.displayName} width="64" height="64" referrerpolicy="no-referrer" />{/if}
                </div>
              {/if}
            {:else}<p>{t.unavailable}</p>{/if}
            <div class="admin-moderation-actions">
              {#if selected.kind === 'mindful' && reviewState === 'published'}
                <button type="button" class="admin-moderation-error" disabled={locked} onclick={() => open('delete')}>{t.delete}</button>
              {:else if selected.kind !== 'reports'}
                <button type="button" class="primary" disabled={locked} onclick={() => open('approve')}>{selected.kind === 'mindful' ? t.approveNow : t.approve}</button>
                <button type="button" disabled={locked} onclick={() => open('reject')}>{t.reject}</button>
              {:else}
                {#if context}<button type="button" disabled={busy} onclick={() => open('hide')}>{t.hide}</button>{/if}
                <button type="button" disabled={busy} onclick={() => open('resolve')}>{t.resolve}</button>
              {/if}
              {#if context?.member && !context.member.isSelf && context.member.status === 'active'}
                <button type="button" class="admin-moderation-error" disabled={locked} onclick={() => context?.member && openSuspend(context.member)}>{t.suspend}</button>
              {/if}
            </div>
            {#if selected.kind === 'mindful'}<p class="mindful-policy">{reviewState === 'pending' ? t.pendingPolicy : t.publishedPolicy}</p>{/if}
          </article>
        {/if}
      </div>
    {/if}
    <nav class="admin-moderation-actions" aria-label={t.title}>
      <button type="button" disabled={locked || queue.isFetching || page === 0} onclick={() => changePage(page - 1)}>{t.previous}</button>
      <button type="button" disabled={locked || queue.isFetching || !queue.data?.nextCursor} onclick={() => changePage(page + 1)}>{t.next}</button>
    </nav>
    {#if kind === 'mindful'}<aside class="mindful-policy"><strong>{t.policyTitle}</strong><p>{personalPracticeCopy[locale.current].sharePolicyWarning}</p><p>{t.moderationPolicyNote}</p></aside>{/if}
  {/if}
</section>
{#if action && principal}<AdminModerationDecisionDialog {action} locale={locale.current} {busy} {error} {conflict} bind:reason mindful={kind === 'mindful'} scope={bulk ? `${bulkScope}\n${t.bulkCount.replace('{count}', countLabel(bulk.preparation.summary))}` : ''} progressText={action === 'approveAll' ? bulkProgress : ''} resuming={action === 'approveAll' && Boolean(bulk?.started)} onClose={close} onConfirm={() => void submit()} onReload={() => void reload()} />{/if}
{#if suspending && principal}<AdminMemberSuspendDialog member={suspending} targetStatus="suspended" {busy} {error} onClose={close} onConfirm={() => submit(true)} />{/if}

<style>
  .admin-moderation-mindful p{text-align:justify}
  .mindful-state-tabs{padding:var(--radius-sm);border:1px solid var(--border2);border-radius:var(--radius-card);background:var(--bg2)}
  .mindful-state-tabs button{flex:1}
  .mindful-state-tabs span{margin-left:var(--radius-sm);font-size:var(--font-size-meta)}
  .mindful-filter button[aria-pressed='true'],.mindful-selected{border-color:var(--gold);background:var(--gold-light)}
  .mindful-review-meta{display:grid;gap:var(--radius-sm);margin:var(--space-page) 0;padding:var(--radius-control);border-radius:var(--radius-control);background:var(--bg2);font-size:var(--font-size-label)}
  .mindful-review-meta div{display:flex;flex-wrap:wrap;justify-content:space-between;gap:var(--radius-sm)}
  .mindful-review-meta dd{margin:0}
  .mindful-policy,.mindful-bulk-progress{border-top:1px solid var(--border2);padding-top:var(--space-page);margin-top:var(--space-page)}
  .admin-moderation-context{scroll-margin-block:calc(var(--nav-h) + var(--space-page))}
</style>
